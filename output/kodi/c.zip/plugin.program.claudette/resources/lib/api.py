"""
Claudette API client — pure stdlib, no third-party deps required.
Works on LibreELEC / Kodi Python 3.

Auth: POSTs to /api/auth/login on each instantiation to get a session
cookie, then sends that cookie on all subsequent requests.
Each Kodi page load is a new Python process, so login is always fast
(one POST) and the cookie is valid for the lifetime of that page request.
"""

import json
import http.cookiejar
import urllib.request
import urllib.error


class ClaudetteAPI:
    def __init__(self, base_url, timeout=10):
        self.base    = base_url.rstrip('/') + '/api'
        self.timeout = timeout
        self._jar    = http.cookiejar.CookieJar()
        self._opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self._jar)
        )

    # ── Auth ──────────────────────────────────────────────────────────────────

    def status(self):
        """GET /api/auth/status → {registered, authenticated, username} or None."""
        return self._get('/auth/status')

    def login(self, username, password):
        """POST /api/auth/login. Returns (True, None) on success,
        (False, error_string) on failure.
        Raises OSError / URLError for connection failures."""
        body = json.dumps({
            'username': username,
            'password': password,
            'remember': False,
        }).encode('utf-8')
        req = urllib.request.Request(
            self.base + '/auth/login',
            data=body,
            headers={
                'Content-Type': 'application/json',
                'Accept':       'application/json',
            },
            method='POST',
        )
        try:
            with self._opener.open(req, timeout=self.timeout) as resp:
                return True, None
        except urllib.error.HTTPError as e:
            try:
                msg = json.loads(e.read().decode('utf-8')).get('error', 'HTTP {0}'.format(e.code))
            except Exception:
                msg = 'HTTP {0}'.format(e.code)
            return False, msg
        except Exception as e:
            raise

    def register(self, username, password):
        """POST /api/auth/register. Returns (True, None) on success,
        (False, error_string) on failure."""
        return self._post_auth('/auth/register', username, password)

    def _post_auth(self, path, username, password):
        body = json.dumps({'username': username, 'password': password}).encode('utf-8')
        req = urllib.request.Request(
            self.base + path,
            data=body,
            headers={'Content-Type': 'application/json', 'Accept': 'application/json'},
            method='POST',
        )
        try:
            with self._opener.open(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                return True, data.get('username')
        except urllib.error.HTTPError as e:
            try:
                msg = json.loads(e.read().decode('utf-8')).get('error', str(e))
            except Exception:
                msg = str(e)
            return False, msg

    # ── Internal ──────────────────────────────────────────────────────────────

    def _get(self, path):
        """GET /api{path} → parsed dict, or None on failure."""
        req = urllib.request.Request(
            self.base + path,
            headers={'Accept': 'application/json'},
        )
        try:
            with self._opener.open(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except (urllib.error.URLError, urllib.error.HTTPError, OSError):
            return None

    def _post(self, path, body=None):
        """POST /api{path} → parsed dict, or None on failure."""
        data = json.dumps(body or {}).encode('utf-8')
        req  = urllib.request.Request(
            self.base + path,
            data=data,
            headers={
                'Content-Type': 'application/json',
                'Accept':       'application/json',
            },
            method='POST',
        )
        try:
            with self._opener.open(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except (urllib.error.URLError, urllib.error.HTTPError, OSError):
            return None

    # ── Public endpoints ──────────────────────────────────────────────────────

    def get_network(self):
        """Returns {devices: [...], lastScan, scanning}"""
        return self._get('/network/scan')

    def trigger_scan(self):
        """Start a background network scan. Returns {started: true}"""
        return self._post('/network/scan')

    def get_services(self):
        """Returns {results: [{name, ok, message, ms, ts}]}"""
        return self._get('/services')

    def get_threats(self):
        """Returns {threats: [{title, severity, package, url, date, summary, source}], lastRefresh}"""
        return self._get('/threats')

    def get_audit(self, limit=50, offset=0):
        """Returns {entries: [{ts, event, actor, payload}], total}"""
        return self._get('/audit?limit={0}&offset={1}'.format(limit, offset))

    def get_stats(self):
        """Returns {cpu, memory, disk, network, os}"""
        return self._get('/system/stats')

    def get_reports(self, limit=50, offset=0):
        """Returns {events, summary, total, from, to}"""
        return self._get('/reports?limit={0}&offset={1}'.format(limit, offset))

