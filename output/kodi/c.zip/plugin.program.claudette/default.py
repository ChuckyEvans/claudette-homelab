"""
Claudette — Kodi plugin entry point.
Full-featured homelab monitor: network, services, threats, audit, system stats.
"""

import sys
import json
import datetime
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from urllib.parse import parse_qsl, urlencode
from resources.lib.api import ClaudetteAPI

ADDON        = xbmcaddon.Addon()
ADDON_URL    = sys.argv[0]
ADDON_HANDLE = int(sys.argv[1])
ADDON_ARGS   = dict(parse_qsl(sys.argv[2][1:]))

SEV_COLOR = {'critical': 'FF4444', 'high': 'FF8800', 'medium': 'FFCC00', 'low': '44AAFF'}
SEV_RANK  = {'low': 1, 'medium': 2, 'high': 3, 'critical': 4}

PORT_RISK_COLOR = {
    'critical': 'FF4444',
    'high':     'FF8800',
    'medium':   'FFCC00',
    'low':      '44AAFF',
    'none':     '555555',
}


# ── Colour helpers ────────────────────────────────────────────────────────────

def c(color, text):
    return '[COLOR FF{0}]{1}[/COLOR]'.format(color, text)

def dim(text):
    return c('666666', text)

def head(text):
    return c('DDDDDD', text)

def pct_color(pct):
    if pct >= 90: return 'FF4444'
    if pct >= 75: return 'FF8800'
    if pct >= 50: return 'FFCC00'
    return '44FF88'

def pct_bar(pct, width=10):
    filled = int(round(pct / 100 * width))
    return '[' + unichr_safe(0x2588) * filled + unichr_safe(0x2591) * (width - filled) + '] {0}%'.format(pct)

def unichr_safe(n):
    try:
        return chr(n)
    except Exception:
        return '#'


# ── URL / item helpers ────────────────────────────────────────────────────────

def url(**kwargs):
    return '{0}?{1}'.format(ADDON_URL, urlencode(kwargs))

def add_item(label, item_url='', is_folder=False, info=None, art=None):
    li = xbmcgui.ListItem(label=label)
    if info:
        li.setInfo('video', info)
    if art:
        li.setArt(art)
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, item_url, li, is_folder)

def end_dir(content='files'):
    xbmcplugin.setContent(ADDON_HANDLE, content)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def err_dialog(title, msg):
    xbmcgui.Dialog().ok('Claudette -- ' + title, msg)

def sep(label=''):
    add_item(dim('--- ' + label + ' ' + '-' * max(0, 36 - len(label))))


# ── Formatting ────────────────────────────────────────────────────────────────

def fmt_bytes(b):
    if b is None: return '?'
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if b < 1024: return '{0:.1f} {1}'.format(b, unit)
        b /= 1024
    return '{0:.1f} PB'.format(b)

def fmt_uptime(secs):
    if secs is None: return '?'
    secs = int(secs)
    d, r = divmod(secs, 86400)
    h, r = divmod(r, 3600)
    m = r // 60
    if d: return '{0}d {1}h {2}m'.format(d, h, m)
    if h: return '{0}h {1}m'.format(h, m)
    return '{0}m'.format(m)

def fmt_ts(ts):
    if not ts: return '--'
    try:
        return datetime.datetime.fromtimestamp(ts / 1000).strftime('%d %b %H:%M')
    except Exception:
        return str(ts)

def fmt_ts_long(ts):
    if not ts: return '--'
    try:
        return datetime.datetime.fromtimestamp(ts / 1000).strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        return str(ts)

def fmt_date(s):
    if not s: return ''
    try:
        dt = datetime.datetime.fromisoformat(s.replace('Z', '+00:00'))
        return dt.strftime('%d %b %Y')
    except Exception:
        return s[:10]


# ── Auth ──────────────────────────────────────────────────────────────────────

def get_api():
    server   = ADDON.getSetting('server_url').strip() or 'http://192.168.8.10:7654'
    timeout  = int(ADDON.getSetting('timeout') or 10)
    username = ADDON.getSetting('username').strip()
    password = ADDON.getSetting('password')

    if not username or not password:
        return None

    api = ClaudetteAPI(server, timeout)
    try:
        srv = api.status()
    except Exception as e:
        err_dialog('Connection Error',
                   'Cannot reach server at:\n{0}\n\nError: {1}\n\nCheck server URL in Settings.'.format(server, e))
        return None

    if srv is None:
        err_dialog('Connection Error',
                   'No response from:\n{0}\n\nCheck URL and that the server is running.'.format(server))
        return None

    if not srv.get('registered'):
        ok, info = api.register(username, password)
        if not ok:
            err_dialog('Registration Failed', str(info))
            return None
        return api

    ok, login_err = api.login(username, password)
    if not ok:
        err_dialog('Login Failed',
                   'Login failed for: {0}\n\nServer said: {1}\n\nUse same credentials as the web UI.'.format(
                       username, login_err or 'Invalid credentials'))
        return None

    return api


# ── Main menu ─────────────────────────────────────────────────────────────────

def main_menu():
    username = ADDON.getSetting('username').strip()
    password = ADDON.getSetting('password')

    api = get_api()
    if api is None:
        if not username or not password:
            add_item(c('FFCC00', 'Not configured') + dim('  -- tap to open Settings'),
                     url(action='open_settings'), is_folder=False,
                     info={'title': 'Configure',
                           'plot': 'Open Settings to enter your server URL, username and password.'})
        else:
            server = ADDON.getSetting('server_url').strip() or 'http://192.168.8.10:7654'
            add_item(c('FF4444', 'Cannot reach server') + dim('  ' + server),
                     url(action='open_settings'), is_folder=False,
                     info={'title': 'Server unreachable',
                           'plot': 'Cannot connect to:\n{0}\n\nTap to open Settings.'.format(server)})
            add_item(c('44AAFF', 'Retry'), ADDON_URL, is_folder=False,
                     info={'title': 'Retry', 'plot': 'Try connecting again.'})
        add_item(dim('Settings'), url(action='open_settings'), is_folder=False,
                 info={'title': 'Settings', 'plot': 'Change server URL, username or password.'})
        end_dir()
        return

    net     = api.get_network()  or {}
    svc_raw = api.get_services() or {}
    thr_raw = api.get_threats()  or {}
    sys_raw = api.get_stats()    or {}

    devices  = net.get('devices', [])
    online   = sum(1 for d in devices if d.get('status') == 'online')
    filtered = sum(1 for d in devices if d.get('status') == 'filtered')
    scanning = net.get('scanning', False)
    last_scan = fmt_ts(net.get('lastScan'))

    svc_list  = svc_raw.get('results', [])
    svc_ok    = sum(1 for s in svc_list if s.get('ok'))
    svc_total = len(svc_list)
    svc_down  = [s for s in svc_list if not s.get('ok')]

    threats  = thr_raw.get('threats', [])
    thr_crit = sum(1 for t in threats if t.get('severity') == 'critical')
    thr_high = sum(1 for t in threats if t.get('severity') == 'high')

    cpu_pct  = sys_raw.get('cpu', {}).get('load', 0)
    mem_pct  = sys_raw.get('memory', {}).get('percent', 0)
    uptime   = fmt_uptime(sys_raw.get('os', {}).get('uptime'))
    hostname = sys_raw.get('os', {}).get('hostname', '')

    # Header
    scan_tag = c('AAAAFF', '  [scanning...]') if scanning else ''
    add_item(c('6666FF', 'CLAUDETTE') + '  ' + dim(hostname or 'homelab') + scan_tag,
             info={'title': 'Claudette',
                   'plot': 'Homelab monitor\nServer: {0}\nLast scan: {1}'.format(
                       ADDON.getSetting('server_url'), last_scan)})

    # Quick stats
    cpu_str = c(pct_color(cpu_pct), 'CPU {0}%'.format(cpu_pct))
    mem_str = c(pct_color(mem_pct), 'MEM {0}%'.format(mem_pct))
    add_item(cpu_str + '   ' + mem_str + '   ' + dim('up ' + uptime),
             url(action='system'),
             info={'title': 'System Stats', 'plot': 'Tap to view full system stats.\nCPU: {0}%\nMEM: {1}%\nUptime: {2}'.format(cpu_pct, mem_pct, uptime)})

    sep()

    # Network
    net_dot = c('44FF88', 'O') if online else c('555555', 'O')
    net_sub = '{0} online'.format(online)
    if filtered: net_sub += ', {0} filtered'.format(filtered)
    if devices:  net_sub += ', {0} total'.format(len(devices))
    net_plot = '{0} devices online\nLast scan: {1}'.format(online, last_scan)
    if scanning: net_plot += '\n[Scanning in progress]'
    add_item('{0}  {1}  {2}'.format(net_dot, c('CCCCCC', 'Network Devices'), dim(net_sub)),
             url(action='devices'), is_folder=True,
             info={'title': 'Network Devices', 'plot': net_plot})

    # Services
    if svc_total:
        svc_pct   = int(svc_ok / svc_total * 100)
        svc_color = '44FF88' if svc_ok == svc_total else ('FF8800' if svc_pct >= 50 else 'FF4444')
        svc_dot   = c(svc_color, 'O')
        svc_sub   = '{0}/{1} healthy'.format(svc_ok, svc_total)
        if svc_down:
            down_names = ', '.join(s.get('name', '?') for s in svc_down[:3])
            svc_sub += '  DOWN: ' + down_names
        svc_plot  = '{0}/{1} healthy ({2}%)\n'.format(svc_ok, svc_total, svc_pct)
        for s in svc_list:
            svc_plot += '\n{0} {1}  {2}'.format('OK' if s.get('ok') else 'DN', s.get('name', ''), s.get('message', ''))
    else:
        svc_dot  = c('555555', 'O')
        svc_sub  = 'none configured'
        svc_plot = 'No services configured.\nAdd services on the web UI.'
    add_item('{0}  {1}  {2}'.format(svc_dot, c('CCCCCC', 'Services'), dim(svc_sub)),
             url(action='services'), is_folder=True,
             info={'title': 'Services', 'plot': svc_plot})

    # Threats
    if thr_crit:
        thr_dot = c('FF4444', 'O')
        thr_sub = c('FF4444', '{0} critical'.format(thr_crit))
        if thr_high: thr_sub += dim(', ') + c('FF8800', '{0} high'.format(thr_high))
    elif thr_high:
        thr_dot = c('FF8800', 'O')
        thr_sub = c('FF8800', '{0} high'.format(thr_high))
    elif threats:
        thr_dot = c('FFCC00', 'O')
        thr_sub = dim('{0} threats'.format(len(threats)))
    else:
        thr_dot = c('44FF88', 'O')
        thr_sub = dim('clean')
    thr_plot = '{0} total threats'.format(len(threats))
    for sev in ('critical', 'high', 'medium', 'low'):
        n = sum(1 for t in threats if t.get('severity') == sev)
        if n: thr_plot += '\n{0}: {1}'.format(sev.upper(), n)
    add_item('{0}  {1}  {2}'.format(thr_dot, c('CCCCCC', 'Threats'), thr_sub),
             url(action='threats'), is_folder=True,
             info={'title': 'Threats', 'plot': thr_plot or 'No threats.'})

    # Reports
    add_item(c('888888', 'O') + '  ' + c('AAAAAA', 'Reports'),
             url(action='reports'), is_folder=True,
             info={'title': 'Reports', 'plot': 'Activity history: device events, scans, service changes (last 7 days).'})

    sep()

    # Actions
    add_item(c('44AAFF', '>') + '  ' + c('AAAAAA', 'Trigger Network Scan'),
             url(action='trigger_scan'), is_folder=False,
             info={'title': 'Trigger Scan', 'plot': 'Start a fresh network scan on the server.'})
    add_item(c('888888', '=') + '  ' + c('AAAAAA', 'Audit Log'),
             url(action='audit'), is_folder=True,
             info={'title': 'Audit Log', 'plot': 'Recent system events.'})
    add_item(c('6666AA', '*') + '  ' + c('777777', 'Settings'),
             url(action='open_settings'), is_folder=False,
             info={'title': 'Settings', 'plot': 'Configure server URL, credentials, and display options.'})

    end_dir()


# ── Devices ───────────────────────────────────────────────────────────────────

def show_devices():
    api  = get_api()
    if api is None: return
    data = api.get_network()
    if data is None:
        err_dialog('Network', 'Could not reach server.'); return

    devices     = data.get('devices', [])
    show_offline = ADDON.getSetting('show_offline_devices') != 'false'
    last_scan   = fmt_ts(data.get('lastScan'))
    scanning    = data.get('scanning', False)

    if not devices:
        add_item(dim('No devices found -- trigger a scan first')); end_dir(); return

    online  = sum(1 for d in devices if d.get('status') == 'online')
    filt    = sum(1 for d in devices if d.get('status') == 'filtered')
    offline = sum(1 for d in devices if d.get('status') not in ('online', 'filtered'))

    summary  = '{0} online'.format(online)
    if filt:    summary += ', {0} filtered'.format(filt)
    if not show_offline: summary += ' (offline hidden)'
    else:       summary += ', {0} offline'.format(offline)
    scan_tag = c('AAAAFF', '  [scanning...]') if scanning else ''
    add_item(head(summary) + scan_tag + dim('  last scan ' + last_scan),
             url(action='trigger_scan'),
             info={'title': 'Scan info',
                   'plot': 'Tap to trigger a new scan.\nLast scan: {0}\n{1} online, {2} filtered, {3} offline'.format(
                       last_scan, online, filt, offline)})

    def sort_key(d):
        fav  = not d.get('favorited', False)
        stat = {'online': 0, 'filtered': 1}.get(d.get('status'), 2)
        try:   octet = int((d.get('ip') or '0').split('.')[-1])
        except ValueError: octet = 0
        return (fav, stat, octet)

    for d in sorted(devices, key=sort_key):
        status = d.get('status', 'offline')
        if status not in ('online', 'filtered') and not show_offline:
            continue

        ip       = d.get('ip', '')
        label    = d.get('label') or ''
        hostname = d.get('hostname') or ''
        name     = label or hostname or ip
        vendor   = d.get('vendor') or ''
        latency  = d.get('latency')
        ports    = [p for p in d.get('ports', []) if p.get('state') == 'open']
        fav      = d.get('favorited', False)
        flagged  = d.get('flagged', False)
        dormant  = d.get('dormant', False)
        os_str   = d.get('os') or ''
        mac      = d.get('mac') or ''

        if status == 'online':      dot = c('44FF88', 'O')
        elif status == 'filtered':  dot = c('FF8800', 'O')
        elif dormant:               dot = c('4466AA', 'O')
        else:                       dot = c('444444', 'O')

        prefix = ''
        if fav:     prefix += c('FFCC00', '* ')
        if flagged: prefix += c('FF4444', '! ')

        name_color = 'FFFFFF' if status == 'online' else ('888888' if status == 'offline' else 'FFCC88')
        row = '{0}  {1}{2}'.format(dot, prefix, c(name_color, name))
        if label and hostname and hostname != label:
            row += '  ' + dim(hostname)
        elif not label and ip != name:
            row += '  ' + dim(ip)
        if status == 'online' and latency is not None:
            row += '  ' + dim('{0}ms'.format(latency))
        if ports:
            row += '  ' + dim('{0}p'.format(len(ports)))

        plot_parts = ['IP: {0}'.format(ip)]
        if mac:     plot_parts.append('MAC: {0}'.format(mac))
        if vendor:  plot_parts.append('Vendor: {0}'.format(vendor))
        if os_str:  plot_parts.append('OS: {0}'.format(os_str))
        if latency is not None: plot_parts.append('Latency: {0}ms'.format(latency))
        if ports:
            plot_parts.append('Open ports:\n  ' + '\n  '.join(
                '{0}/{1} ({2})'.format(p['port'], p.get('protocol', 'tcp'), p.get('service', ''))
                for p in ports[:20]))
        if status == 'offline':
            plot_parts.append('Last seen: {0}'.format(fmt_ts(d.get('lastSeen'))))
        if dormant: plot_parts.append('[Marked dormant]')

        add_item(row, url(action='device_detail', ip=ip), is_folder=True,
                 info={'title': name, 'plot': '\n'.join(plot_parts)})

    end_dir()


def show_device_detail():
    ip  = ADDON_ARGS.get('ip', '')
    api = get_api()
    if api is None: return
    data = api.get_network()
    if not data:
        err_dialog('Network', 'Could not reach server.'); return

    device = next((d for d in data.get('devices', []) if d.get('ip') == ip), None)
    if not device:
        err_dialog('Not Found', 'Device {0} not found.'.format(ip)); return

    label    = device.get('label') or ''
    hostname = device.get('hostname') or ''
    name     = label or hostname or ip
    online   = device.get('status') == 'online'
    latency  = device.get('latency')
    vendor   = device.get('vendor') or 'Unknown'
    os_str   = device.get('os') or 'Unknown'
    mac      = device.get('mac') or '--'
    ports    = [p for p in device.get('ports', []) if p.get('state') == 'open']
    hscripts = device.get('hostScripts') or device.get('host_scripts') or []
    route    = device.get('traceroute') or []
    fav      = device.get('favorited', False)
    flagged  = device.get('flagged', False)
    dormant  = device.get('dormant', False)

    stat_dot = c('44FF88' if online else '555555', 'O')
    prefix   = (c('FFCC00', '* ') if fav else '') + (c('FF4444', '! ') if flagged else '')
    add_item('{0}  {1}{2}  {3}'.format(stat_dot, prefix, c('FFFFFF', name), dim(ip)),
             info={'title': name,
                   'plot': 'IP: {0}\nMAC: {1}\nVendor: {2}\nOS: {3}\nStatus: {4}{5}'.format(
                       ip, mac, vendor, os_str, device.get('status', ''),
                       '\nLatency: {0}ms'.format(latency) if latency is not None else '')})

    sep('Info')
    rows = [('IP', ip), ('MAC', mac), ('Vendor', vendor), ('OS', os_str),
            ('Hostname', hostname or '--'), ('Status', device.get('status', '--'))]
    if latency is not None: rows.append(('Latency', '{0}ms'.format(latency)))
    rows.append(('First seen', fmt_ts(device.get('firstSeen'))))
    rows.append(('Last seen',  fmt_ts(device.get('lastSeen') or device.get('last_online'))))
    for k, v in rows:
        add_item(dim('{0:<12}'.format(k + ':')) + '  ' + c('CCCCCC', str(v)),
                 info={'title': k, 'plot': '{0}: {1}'.format(k, v)})

    sep('Open Ports ({0})'.format(len(ports)))
    if not ports:
        add_item(dim('No open ports detected -- run a deep scan'))
    else:
        for p in ports:
            port_num = p.get('port', '?')
            proto    = p.get('protocol', 'tcp')
            svc      = p.get('service', '')
            version  = p.get('version', '')
            scripts  = p.get('scripts') or []
            risk     = p.get('risk', 'none')
            risk_col = PORT_RISK_COLOR.get(risk, '555555')
            banner   = scripts[0][:60] if scripts else (version[:60] if version else '')
            row = c(risk_col, str(port_num)) + dim('/{0}'.format(proto))
            if svc:     row += '  ' + c('CCCCCC', svc)
            if risk and risk != 'none': row += '  ' + c(risk_col, '[{0}]'.format(risk.upper()))
            if banner:  row += '  ' + dim(banner)
            plot = '{0}/{1}  {2}\nRisk: {3}'.format(port_num, proto, svc, risk)
            if version: plot += '\nVersion: ' + version
            if scripts: plot += '\n\n' + '\n'.join(scripts[:5])
            add_item(row, info={'title': '{0}/{1} {2}'.format(port_num, proto, svc), 'plot': plot})

    if hscripts:
        sep('Host Scripts')
        for line in (hscripts if isinstance(hscripts, list) else [hscripts])[:15]:
            add_item(dim(str(line)[:120]), info={'title': 'Script', 'plot': str(line)})

    if route:
        sep('Network Path ({0} hops)'.format(len(route)))
        for hop in route:
            add_item(dim('Hop {0}'.format(hop.get('hop', '?'))) +
                     '  ' + c('AAAACC', hop.get('address', '?')) +
                     '  ' + dim('{0}ms'.format(hop.get('rtt', '?'))),
                     info={'title': 'Hop {0}'.format(hop.get('hop')),
                           'plot': 'Address: {0}\nRTT: {1}ms'.format(hop.get('address'), hop.get('rtt'))})

    end_dir()


# ── Services ──────────────────────────────────────────────────────────────────

def show_services():
    api  = get_api()
    if api is None: return
    data = api.get_services()
    if data is None:
        err_dialog('Services', 'Could not reach server.'); return

    results = data.get('results', [])
    if not results:
        add_item(dim('No services configured -- add them in Settings on the web UI'))
        end_dir(); return

    ok_count = sum(1 for s in results if s.get('ok'))
    total    = len(results)
    pct      = int(ok_count / total * 100) if total else 0
    hdr_col  = '44FF88' if ok_count == total else ('FF8800' if pct >= 50 else 'FF4444')
    add_item(c(hdr_col, '{0}/{1} healthy'.format(ok_count, total)) + dim('  ({0}%)'.format(pct)),
             info={'title': 'Services summary',
                   'plot': '{0}/{1} services healthy ({2}%)'.format(ok_count, total, pct)})

    for svc in sorted(results, key=lambda r: (r.get('ok', False), r.get('name', '').lower())):
        ok      = svc.get('ok', False)
        name    = svc.get('name', 'Unknown')
        message = svc.get('message', '')
        ms      = svc.get('ms')
        avg_ms  = svc.get('avg_ms')
        uptime  = svc.get('uptime_pct')

        dot    = c('44FF88', 'O') if ok else c('FF4444', 'O')
        status = c('44FF88', 'OK') if ok else c('FF4444', 'DOWN')
        row    = '{0}  {1}  {2}'.format(dot, c('FFFFFF' if ok else 'FF8888', name), status)
        if ms is not None:     row += '  ' + dim('{0}ms'.format(ms))
        if uptime is not None:
            up_col = '44FF88' if uptime >= 99 else ('FFCC00' if uptime >= 90 else 'FF4444')
            row += '  ' + c(up_col, '{0:.1f}%'.format(uptime))

        plot = 'Status: {0}'.format('OK' if ok else 'DOWN')
        if message:            plot += '\nMessage: {0}'.format(message)
        if ms is not None:     plot += '\nResponse: {0}ms'.format(ms)
        if avg_ms is not None: plot += '\nAverage: {0}ms'.format(avg_ms)
        if uptime is not None: plot += '\nUptime: {0:.1f}%'.format(uptime)

        add_item(row, info={'title': name, 'plot': plot.strip()})

    end_dir()


# ── Threats ───────────────────────────────────────────────────────────────────

def show_threats():
    api  = get_api()
    if api is None: return
    data = api.get_threats()
    if data is None:
        err_dialog('Threats', 'Could not reach server.'); return

    raw_sev = ADDON.getSetting('threat_min_severity') or '1'
    if raw_sev.lstrip('-').isdigit():
        min_sev_str = ['low', 'medium', 'high', 'critical'][min(int(raw_sev), 3)]
    else:
        min_sev_str = raw_sev.lower() if raw_sev.lower() in SEV_RANK else 'medium'
    min_level = SEV_RANK[min_sev_str]

    all_threats = data.get('threats', [])
    threats     = [t for t in all_threats if SEV_RANK.get(t.get('severity', 'low'), 1) >= min_level]
    last_refresh = fmt_ts(data.get('lastRefresh'))

    counts = {}
    for sev in ('critical', 'high', 'medium', 'low'):
        n = sum(1 for t in all_threats if t.get('severity') == sev)
        if n: counts[sev] = n
    summary_parts = [c(SEV_COLOR[sev], '{0} {1}'.format(n, sev)) for sev, n in counts.items()]
    hdr = '  '.join(summary_parts) if summary_parts else c('44FF88', 'No threats')
    add_item(hdr + dim('  refreshed ' + last_refresh),
             info={'title': 'Threat summary',
                   'plot': 'Total: {0}\nShowing: {1}+\nLast refresh: {2}'.format(
                       len(all_threats), min_sev_str, last_refresh)})

    if not threats:
        add_item(dim('No threats at or above {0} severity'.format(min_sev_str)))
        end_dir(); return

    groups = {}
    for t in threats:
        key = t.get('package') or t.get('source') or 'Other'
        groups.setdefault(key, []).append(t)

    def worst(ts):
        return max(SEV_RANK.get(t.get('severity', 'low'), 1) for t in ts)

    for pkg_name, pkg_threats in sorted(groups.items(), key=lambda kv: -worst(kv[1])):
        w        = worst(pkg_threats)
        sev_name = {1: 'low', 2: 'medium', 3: 'high', 4: 'critical'}[w]
        color    = SEV_COLOR.get(sev_name, '888888')
        count    = len(pkg_threats)
        add_item(c(color, '[{0}]'.format(sev_name.upper())) + '  ' + c('FFFFFF', pkg_name) +
                 dim('  {0} issue{1}'.format(count, 's' if count != 1 else '')),
                 url(action='threat_group', package=pkg_name), is_folder=True,
                 info={'title': pkg_name,
                       'plot': '{0} vulnerabilities\nWorst: {1}\n\n{2}'.format(
                           count, sev_name.upper(),
                           '\n'.join(t.get('title', '') for t in pkg_threats[:5]))})

    end_dir()


def show_threat_group():
    pkg  = ADDON_ARGS.get('package', '')
    api  = get_api()
    if api is None: return
    data = api.get_threats()
    if not data:
        err_dialog('Threats', 'Could not reach server.'); return

    threats = [t for t in data.get('threats', [])
               if (t.get('package') or t.get('source') or 'Other') == pkg]

    if not threats:
        add_item(dim('No threats for: ' + pkg)); end_dir(); return

    add_item(head(pkg) + dim('  {0} issue{1}'.format(len(threats), 's' if len(threats) != 1 else '')),
             info={'title': pkg, 'plot': '{0} vulnerabilities in {1}'.format(len(threats), pkg)})

    for t in sorted(threats, key=lambda x: -SEV_RANK.get(x.get('severity', 'low'), 1)):
        sev   = t.get('severity', 'low')
        color = SEV_COLOR.get(sev, '888888')
        title = t.get('title', 'Unknown')
        date  = fmt_date(t.get('date', ''))
        link  = t.get('url', '')
        row   = c(color, '[{0}]'.format(sev.upper())) + '  ' + c('DDDDDD', title[:90])
        if date: row += '  ' + dim(date)
        plot  = title + '\nSeverity: ' + sev.upper()
        if t.get('summary'): plot += '\n\n' + t['summary']
        if t.get('source'):  plot += '\n\nSource: ' + t['source']
        if date:             plot += '\nDate: ' + date
        if link:             plot += '\n\n' + link
        add_item(row, info={'title': title, 'plot': plot})

    end_dir()


# ── Audit Log ─────────────────────────────────────────────────────────────────

EVENT_COLOR = {
    'scan.complete': '6666FF', 'scan.started': '8888FF', 'scan.error': 'FF4444',
    'service.check': '888888', 'service.down': 'FF4444', 'service.up': '44FF88',
    'threat.refresh': 'FFAA00', 'config.saved': '44AAFF',
    'auth.login': '44FF88', 'auth.register': '44AAFF', 'auth.login_failed': 'FF4444',
    'internet.check': '888888', 'device.online': '44FF88', 'device.offline': '888888',
}


def show_audit():
    api   = get_api()
    if api is None: return
    limit = int(ADDON.getSetting('audit_limit') or 50)
    page  = int(ADDON_ARGS.get('page', 0))
    data  = api.get_audit(limit=limit, offset=page * limit)
    if data is None:
        err_dialog('Audit Log', 'Could not reach server.'); return

    entries = data.get('entries', [])
    total   = data.get('total', 0)
    pages   = max(1, (total + limit - 1) // limit)

    add_item(head('Audit Log') + dim('  {0} events  page {1}/{2}'.format(total, page + 1, pages)),
             info={'title': 'Audit Log',
                   'plot': '{0} total events\nPage {1}/{2}'.format(total, page + 1, pages)})

    if not entries:
        add_item(dim('No audit events yet')); end_dir(); return

    for e in entries:
        event   = e.get('event', '')
        ts      = fmt_ts_long(e.get('ts'))
        actor   = e.get('actor', 'system')
        payload = e.get('payload') or {}
        color   = EVENT_COLOR.get(event, '888888')

        parts = []
        if payload.get('devices_found') is not None: parts.append('{0} devices'.format(payload['devices_found']))
        if payload.get('subnet'):      parts.append(payload['subnet'])
        if payload.get('name'):        parts.append(payload['name'])
        if payload.get('new_count'):   parts.append('{0} new'.format(payload['new_count']))
        if payload.get('up') is not None:
            parts.append('{0} up / {1} down'.format(payload['up'], payload.get('down', 0)))
        if payload.get('error'):       parts.append(payload['error'][:40])
        detail = '  ' + dim(' / '.join(str(p) for p in parts)) if parts else ''

        row  = dim(ts[:16]) + '  ' + c(color, event) + detail
        if actor and actor != 'system': row += '  ' + dim(actor)

        plot = 'Event: {0}\nActor: {1}\nTime: {2}'.format(event, actor, ts)
        if payload:
            plot += '\n\n' + json.dumps(payload, indent=2)[:400]

        add_item(row, info={'title': event, 'plot': plot})

    sep()
    if page > 0:
        add_item(c('44AAFF', '< Previous page'),
                 url(action='audit', page=page - 1), is_folder=True,
                 info={'title': 'Previous', 'plot': 'Page {0}'.format(page)})
    if page < pages - 1:
        add_item(c('44AAFF', 'Next page >'),
                 url(action='audit', page=page + 1), is_folder=True,
                 info={'title': 'Next', 'plot': 'Page {0}'.format(page + 2)})

    end_dir()


# ── System Stats ──────────────────────────────────────────────────────────────

def show_system():
    api  = get_api()
    if api is None: return
    data = api.get_stats()
    if data is None:
        err_dialog('System', 'Could not reach server.'); return

    cpu   = data.get('cpu', {})
    mem   = data.get('memory', {})
    disks = data.get('disk', [])
    nets  = data.get('network', [])
    os_d  = data.get('os', {})

    hostname = os_d.get('hostname', '')
    distro   = '{0} {1}'.format(os_d.get('distro', ''), os_d.get('release', '')).strip()
    arch     = os_d.get('arch', '')
    uptime   = fmt_uptime(os_d.get('uptime'))

    add_item(c('DDDDDD', hostname or 'System') + dim('  ' + distro + '  ' + arch),
             info={'title': 'System',
                   'plot': 'Host: {0}\nOS: {1}\nArch: {2}\nKernel: {3}\nUptime: {4}'.format(
                       hostname, distro, arch, os_d.get('kernel', ''), uptime)})
    add_item(dim('Uptime: ') + c('AAAAFF', uptime),
             info={'title': 'Uptime', 'plot': 'System uptime: ' + uptime})

    sep('CPU')
    cpu_pct   = cpu.get('load', 0)
    cpu_model = cpu.get('model', 'Unknown')
    cores     = cpu.get('cores', 1)
    per_core  = cpu.get('perCore', [])
    add_item(dim('Load:  ') + c(pct_color(cpu_pct), pct_bar(cpu_pct)) +
             dim('  {0} core{1}'.format(cores, 's' if cores != 1 else '')),
             info={'title': 'CPU', 'plot': 'Load: {0}%\nModel: {1}\nCores: {2}'.format(cpu_pct, cpu_model, cores)})
    add_item(dim('Model: ') + c('CCCCCC', cpu_model[:70]),
             info={'title': 'CPU Model', 'plot': cpu_model})
    if per_core:
        core_str = '  '.join(c(pct_color(p), 'C{0}:{1}%'.format(i, p)) for i, p in enumerate(per_core))
        add_item(dim('Cores: ') + core_str,
                 info={'title': 'Per-core', 'plot': '\n'.join('C{0}: {1}%'.format(i, p) for i, p in enumerate(per_core))})

    sep('Memory')
    mem_pct   = mem.get('percent', 0)
    mem_used  = fmt_bytes(mem.get('used', 0))
    mem_total = fmt_bytes(mem.get('total', 0))
    mem_free  = fmt_bytes(mem.get('free', 0))
    add_item(dim('Used:  ') + c(pct_color(mem_pct), pct_bar(mem_pct)) +
             dim('  {0} / {1}'.format(mem_used, mem_total)),
             info={'title': 'Memory', 'plot': 'Used: {0}\nFree: {1}\nTotal: {2}'.format(mem_used, mem_free, mem_total)})
    if mem.get('swapTotal', 0) > 0:
        add_item(dim('Swap:  ') + c('888888', '{0} / {1}'.format(
                     fmt_bytes(mem.get('swapUsed', 0)), fmt_bytes(mem.get('swapTotal', 0)))),
                 info={'title': 'Swap', 'plot': 'Swap used: {0} / {1}'.format(
                     fmt_bytes(mem.get('swapUsed', 0)), fmt_bytes(mem.get('swapTotal', 0)))})

    if disks:
        sep('Disk')
        for d in disks:
            pct    = d.get('use', 0)
            mount  = d.get('mount', '?')
            fstype = d.get('type', '')
            used   = fmt_bytes(d.get('used', 0))
            size   = fmt_bytes(d.get('size', 0))
            add_item(c(pct_color(pct), pct_bar(pct, 8)) +
                     dim('  ') + c('CCCCCC', mount) +
                     dim('  {0} / {1}  {2}'.format(used, size, fstype)),
                     info={'title': mount,
                           'plot': 'Mount: {0}\nType: {1}\nUsed: {2}\nTotal: {3}\nUsage: {4}%'.format(
                               mount, fstype, used, size, pct)})

    if nets:
        sep('Network')
        for n in nets:
            iface  = n.get('iface', '?')
            rx_s   = n.get('rx_sec', 0)
            tx_s   = n.get('tx_sec', 0)
            rx_tot = fmt_bytes(n.get('rx_bytes', 0))
            tx_tot = fmt_bytes(n.get('tx_bytes', 0))
            add_item(c('AAAACC', iface) +
                     dim('  down ') + c('44FF88', fmt_bytes(rx_s) + '/s') +
                     dim('  up ') + c('44AAFF', fmt_bytes(tx_s) + '/s') +
                     dim('  total rx={0} tx={1}'.format(rx_tot, tx_tot)),
                     info={'title': iface,
                           'plot': 'Interface: {0}\nDown: {1}/s  (total {2})\nUp: {3}/s  (total {4})'.format(
                               iface, fmt_bytes(rx_s), rx_tot, fmt_bytes(tx_s), tx_tot)})

    end_dir()


# ── Reports ──────────────────────────────────────────────────────────────────

REPORT_EVENT_COLOR = {
    'device.new':       '44FF88',
    'device.online':    '44AAFF',
    'device.offline':   '555555',
    'device.port.open': '8888FF',
    'service.down':     'FF4444',
    'service.up':       '44FF88',
    'internet.down':    'FF4444',
    'internet.up':      '44FF88',
    'internet.check':   '666666',
    'scan.complete':    '6666FF',
    'scan.started':     '8888FF',
    'threat.found':     'FFAA00',
}


def show_reports():
    api  = get_api()
    if api is None: return
    page  = int(ADDON_ARGS.get('page', 0))
    limit = int(ADDON.getSetting('audit_limit') or 50)
    data  = api.get_reports(limit=limit, offset=page * limit)
    if data is None:
        err_dialog('Reports', 'Could not reach server.'); return

    summary = data.get('summary', {})
    events  = data.get('events', [])
    total   = data.get('total', 0)
    pages   = max(1, (total + limit - 1) // limit)
    from_ts = data.get('from', 0)
    to_ts   = data.get('to', 0)

    # ── Summary header ──
    period = '{0} - {1}'.format(fmt_ts(from_ts), fmt_ts(to_ts))
    add_item(head('Reports') + dim('  ' + period + '  page {0}/{1}'.format(page + 1, pages)),
             info={'title': 'Reports',
                   'plot': 'Activity for:\n{0}\n{1} total events'.format(period, total)})

    # ── Summary stat tiles ──
    new_dev  = summary.get('newDevices', 0)
    scans    = summary.get('scansRun', 0)
    svc_down = summary.get('serviceDown', 0)
    ports    = summary.get('portFinds', 0)
    dev_on   = summary.get('onlineEvents', 0)
    dev_off  = summary.get('offlineEvents', 0)

    add_item(
        c('44FF88', '{0}'.format(new_dev)) + dim(' new devices') +
        '   ' + c('6666FF', '{0}'.format(scans)) + dim(' scans') +
        '   ' + c('FF4444' if svc_down else '44FF88', '{0}'.format(svc_down)) + dim(' svc down'),
        info={'title': 'Summary',
              'plot': 'New devices: {0}\nScans run: {1}\nService outages: {2}\nPort discoveries: {3}\nDevice online events: {4}\nDevice offline events: {5}'.format(
                  new_dev, scans, svc_down, ports, dev_on, dev_off)})
    add_item(
        c('44AAFF', '{0}'.format(dev_on)) + dim(' came online') +
        '   ' + c('555555', '{0}'.format(dev_off)) + dim(' went offline') +
        '   ' + c('8888FF', '{0}'.format(ports)) + dim(' ports found'),
        info={'title': 'Device events',
              'plot': 'Online: {0}\nOffline: {1}\nNew ports: {2}'.format(dev_on, dev_off, ports)})

    if not events:
        sep()
        add_item(dim('No events in this period'))
        end_dir(); return

    sep('Events ({0})'.format(total))

    for e in events:
        event    = e.get('event', '')
        ts       = fmt_ts_long(e.get('ts'))
        ip       = e.get('ip') or ''
        hostname = e.get('hostname') or ''
        mac      = e.get('mac') or ''
        payload  = e.get('payload') or {}
        source   = e.get('source', 'system')
        color    = REPORT_EVENT_COLOR.get(event, '888888')

        # Build identity string (device or system event)
        identity = ip or hostname or ''
        if hostname and ip and hostname != ip:
            identity = '{0} ({1})'.format(hostname, ip)

        # Build detail from payload
        parts = []
        if payload.get('port'):           parts.append('port {0}'.format(payload['port']))
        if payload.get('name'):           parts.append(payload['name'])
        if payload.get('devices_found') is not None: parts.append('{0} devices'.format(payload['devices_found']))
        if payload.get('up') is not None: parts.append('{0} up/{1} down'.format(payload['up'], payload.get('down', 0)))
        if payload.get('error'):          parts.append(payload['error'][:40])
        detail = ' / '.join(str(p) for p in parts)

        row = dim(ts[:16]) + '  ' + c(color, event)
        if identity: row += '  ' + c('CCCCCC', identity)
        if detail:   row += '  ' + dim(detail)

        plot = 'Event: {0}\nTime: {1}'.format(event, ts)
        if ip:       plot += '\nIP: ' + ip
        if mac:      plot += '\nMAC: ' + mac
        if hostname: plot += '\nHostname: ' + hostname
        if payload:
            plot += '\n\n' + json.dumps(payload, indent=2)[:400]

        add_item(row, info={'title': event, 'plot': plot})

    sep()
    if page > 0:
        add_item(c('44AAFF', '< Previous page'),
                 url(action='reports', page=page - 1), is_folder=True,
                 info={'title': 'Previous', 'plot': 'Page {0}'.format(page)})
    if page < pages - 1:
        add_item(c('44AAFF', 'Next page >'),
                 url(action='reports', page=page + 1), is_folder=True,
                 info={'title': 'Next', 'plot': 'Page {0}'.format(page + 2)})

    end_dir()


# ── Trigger scan ──────────────────────────────────────────────────────────────

def trigger_scan():
    api  = get_api()
    if api is None: return
    resp = api.trigger_scan()
    if resp and resp.get('started'):
        xbmcgui.Dialog().notification('Claudette', 'Network scan started', xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        err_dialog('Scan', 'Could not start scan.')
    xbmc.executebuiltin('Container.Refresh')


# ── Settings ──────────────────────────────────────────────────────────────────

def open_settings():
    ADDON.openSettings()
    xbmc.executebuiltin('Container.Update({0},replace)'.format(ADDON_URL))


# ── Router ────────────────────────────────────────────────────────────────────

ROUTES = {
    'devices':       show_devices,
    'device_detail': show_device_detail,
    'services':      show_services,
    'threats':       show_threats,
    'threat_group':  show_threat_group,
    'audit':         show_audit,
    'reports':       show_reports,
    'system':        show_system,
    'trigger_scan':  trigger_scan,
    'open_settings': open_settings,
}

action = ADDON_ARGS.get('action')
if action and action in ROUTES:
    ROUTES[action]()
else:
    main_menu()

